// Priority helper
