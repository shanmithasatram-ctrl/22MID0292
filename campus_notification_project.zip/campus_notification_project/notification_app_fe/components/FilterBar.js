// Filter Bar component
