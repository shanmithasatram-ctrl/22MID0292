// Notification Card component
