// Priority calculation service
