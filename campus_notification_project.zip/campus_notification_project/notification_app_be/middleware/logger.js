// Backend logger middleware
